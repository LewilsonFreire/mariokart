angular.module('corrida', ['ngRoute']);

angular.module('corrida').config(Config);

Config.$inject = ['$routeProvider']

function Config($routeProvider) {
    $routeProvider
        .when("/login", {
            templateUrl: "js/login/loginJogador.html"
        }).when("/cadastro", {
            templateUrl: "js/cadastro/cadastroJogador.html"
        }).when("/corrida", {
            templateUrl: "js/corrida/corrida.html"
        }).otherwise({
            redirectTo: "/login"
        });
}