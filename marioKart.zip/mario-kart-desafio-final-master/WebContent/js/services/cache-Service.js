angular.module('corrida')
    .service('CacheService', CacheService);

CacheService.$inject = [];

function CacheService() {

    const self = this;
    self.usuarioRegistrado = null;
}