angular.module('corrida')
    .factory('JogadorService', JogadorService)

JogadorService.$inject = ['$http'];

function JogadorService($http) {
    const _jogadoresCadastrados = [];

    const _cadastrarJogador = jogador => {
        let { nickname, senha, personagem } = jogador

        let codificarSenha = {
            nickname,
            senha: btoa(senha),
            personagem
        };
        return $http.post('http://localhost:8080/mario-kart-desafio-final/jogador', codificarSenha);
    }
    return {
        getjogadoresCadastrados: _jogadoresCadastrados,
        cadastrarJogador: _cadastrarJogador
    }
}