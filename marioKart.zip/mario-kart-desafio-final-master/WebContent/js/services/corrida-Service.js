angular.module("corrida").factory("CorridaService", function($http) {
    var baseUrl = 'http://localhost:8080/mario-kart-desafio-final/jogador/correr';
    const _startCorrida = function() {
        return $http.get(baseUrl);

    };
    return {
        startCorrida: _startCorrida
    };
});