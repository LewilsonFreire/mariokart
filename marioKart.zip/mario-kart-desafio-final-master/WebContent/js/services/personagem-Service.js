angular.module("corrida").factory("PersonagemService", function($http) {
    var baseUrl = 'http://localhost:8080/mario-kart-desafio-final/personagem';
    const _pegarPersonagens = function() {
        return $http.get(baseUrl);
    };

    return {
        pegarPersonagens: _pegarPersonagens
    };
});