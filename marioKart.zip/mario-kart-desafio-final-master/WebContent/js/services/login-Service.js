angular.module('corrida')
    .factory('LoginService', LoginService);

LoginService.$inject = ["$http"];

function LoginService($http) {
    const logando = 'http://localhost:8080/mario-kart-desafio-final/jogador/logar';

    const self = this;
    self.jogador = null;

    const _conectar = function(acessoLogin) {
        let { nickname, senha } = acessoLogin

        let codificarAcesso = {
            nickname,
            senha: btoa(senha)
        };

        return $http.post(logando, codificarAcesso);
    };

    return {
        conectar: _conectar
    };

}