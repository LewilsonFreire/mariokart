angular.module('corrida')
    .controller('LoginController', LoginController);

LoginController.$inject = ['$scope', '$location', 'LoginService', 'CacheService'];

function LoginController($scope, $location, LoginService, CacheService) {
    const self = this;
    self.aviso = "";
    self.cache = CacheService;
    self.acessoDados = {
        nickname: '',
        senha: ''
    }

    self.ls = LoginService;

    self.logando = function(dados) {
        self.ls.conectar(dados).then(
            response => {
                console.log(response)
                self.cache.usuarioRegistrado = response.data
                $location.path("/corrida")
            },
            error => {
                console.log(error);
                // self.aviso = error.data.mensagem;
                self.aviso = "Ops! Seu nickname ou senha estão incorretos!";
            }
        )
    }
    self.irTelaCadastro = function() {
        $location.path("/cadastro");
    }
}