angular.module("corrida").controller("PersonagemController",
    PersonagemController);

PersonagemController.$inject = ['$scope', 'PersonagemService'];

function PersonagemController($scope, PersonagemService) {
    var self = this;
    self.ps = PersonagemService;
    self.personagens = [];

    self.init = function() {
        self.carregarPersonagens();
    };

    self.carregarPersonagens = function() {
        self.ps.pegarPersonagens().then(
            response => {
                console.log(response)
                self.personagens = response.data
            },
            error => {
                console.log(error);
            }
        )
    };
}