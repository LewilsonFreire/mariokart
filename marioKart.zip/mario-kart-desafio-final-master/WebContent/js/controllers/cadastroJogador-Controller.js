angular.module('corrida')
    .controller('CadastroController', CadastroController);

CadastroController.$inject = ['$scope', '$location', 'JogadorService'];

function CadastroController($scope, $location, JogadorService) {
    const self = this;
    self.registroUsuario = {
        nickname: null,
        senha: null,
        personagem: null
    };
    self.aviso = "";
    self.js = JogadorService;

    self.registrar = function(jogador) {
        self.js.cadastrarJogador(jogador).then(
            response => {
                $location.path("/login")
            },
            error => {
                console.log(error);
                self.aviso = error.data.mensagem;
            }
        )
    }
}