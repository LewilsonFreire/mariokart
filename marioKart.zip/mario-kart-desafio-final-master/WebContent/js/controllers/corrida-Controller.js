angular.module("corrida").controller("CorridaController",
    CorridaController);

PersonagemController.$inject = ['$scope', 'CorridaService', 'CacheService', 'PersonagemService'];

function CorridaController($scope, CorridaService, CacheService, PersonagemService) {
    const self = this;
    self.service = CorridaService;
    self.cache = CacheService;
    self.ps = PersonagemService;
    self.jogadorVenceu = false;
    self.acabouCorrida = false;
    self.idVencedor = 0;
    self.personagens = [];

    self.start = function() {
        console.log(self.cache.usuarioRegistrado)
        self.service.startCorrida().then(
            response => {
                console.log(response);
                self.idVencedor = response.data.IdPersonagem;
                console.log(self.idVencedor);
                if (self.idVencedor == self.cache.usuarioRegistrado.personagem.id) {
                    self.jogadorVenceu = true;
                }
                self.acabouCorrida = true;
            },
            error => {
                console.log(error);
            }
        )
    }
    self.init = function() {
        self.carregarPersonagens();
    };

    self.carregarPersonagens = function() {
        self.ps.pegarPersonagens().then(
            response => {
                console.log(response)
                self.personagens = response.data
            },
            error => {
                console.log(error);
            }
        )
    };
}