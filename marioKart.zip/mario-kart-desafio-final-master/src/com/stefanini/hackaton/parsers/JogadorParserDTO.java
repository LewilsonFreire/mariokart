package com.stefanini.hackaton.parsers;

import com.stefanini.hackaton.dto.JogadorDto;
import com.stefanini.hackaton.dto.PersonagemDto;
import com.stefanini.hackaton.entities.Jogador;
import com.stefanini.hackaton.entities.Personagem;

public class JogadorParserDTO extends AbstractParser<JogadorDto, Jogador>{

	@Override
    public JogadorDto toDTO(Jogador jog) {
        JogadorDto dto = new JogadorDto();
        dto.setPersonagem(new PersonagemDto());
        dto.setId(jog.getId());
        dto.setNickname(jog.getNickname());
        dto.getPersonagem().setVelocidade(jog.getPersonagem().getVelocidade());
        dto.getPersonagem().setAceleracao(jog.getPersonagem().getAceleracao());
        dto.getPersonagem().setTracao(jog.getPersonagem().getTracao());
        dto.getPersonagem().setNome(jog.getPersonagem().getNome());
        dto.getPersonagem().setPeso(jog.getPersonagem().getPeso());
        dto.getPersonagem().setTurbo(jog.getPersonagem().getTurbo());
        dto.getPersonagem().setManobra(jog.getPersonagem().getManobra());
        dto.getPersonagem().setId(jog.getPersonagem().getId());
            return dto;
    }

	@Override
    public Jogador toEntity(JogadorDto dto) {
        Jogador jog = new Jogador();
        jog.setId(dto.getId());
        jog.setPersonagem(new Personagem());
        jog.setNickname(dto.getNickname());
        jog.getPersonagem().setAceleracao(dto.getPersonagem().getAceleracao());
        jog.getPersonagem().setVelocidade(dto.getPersonagem().getVelocidade());
        jog.getPersonagem().setPeso(dto.getPersonagem().getPeso());
        jog.getPersonagem().setTurbo(dto.getPersonagem().getTurbo());
        jog.getPersonagem().setNome(dto.getPersonagem().getNome());
        jog.getPersonagem().setManobra(dto.getPersonagem().getManobra());
        jog.getPersonagem().setTracao(dto.getPersonagem().getTracao());
        jog.getPersonagem().setId(dto.getPersonagem().getId());
        return jog;
    }

}
