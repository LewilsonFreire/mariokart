package com.stefanini.hackaton.dto;

public class CorridaDto {
	
	private Integer IdPersonagem;

	public Integer getIdPersonagem() {
		return IdPersonagem;
	}
	public void setIdPersonagem(Integer idPersonagem) {
		IdPersonagem = idPersonagem;
	}
}