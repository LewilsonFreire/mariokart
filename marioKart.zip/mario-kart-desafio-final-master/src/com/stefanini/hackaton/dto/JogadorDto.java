package com.stefanini.hackaton.dto;

public class JogadorDto {

	private Integer id;
	private String nickname;
	
	private PersonagemDto personagem;

	public PersonagemDto getPersonagem() {
		return personagem;
	}

	public void setPersonagem(PersonagemDto personagem) {
		this.personagem = personagem;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

}
