package com.stefanini.hackaton.dto;

public class RegistroDto {

	private String senha;
	private String nickname;
	
	private PersonagemDto personagem;

	public PersonagemDto getPersonagem() {
		return personagem;
	}
	public void setPersonagem(PersonagemDto personagem) {
		this.personagem = personagem;
	}
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

}