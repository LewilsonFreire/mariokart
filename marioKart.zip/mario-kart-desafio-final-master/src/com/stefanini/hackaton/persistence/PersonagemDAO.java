package com.stefanini.hackaton.persistence;

import com.stefanini.hackaton.entities.Personagem;

public class PersonagemDAO 
		extends GenericDAO<Integer, Personagem> {

}
