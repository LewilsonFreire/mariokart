package com.stefanini.hackaton.persistence;

import com.stefanini.hackaton.entities.Jogador;

public class JogadorDAO  extends GenericDAO<Integer, Jogador >{

}
