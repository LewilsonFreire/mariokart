package com.stefanini.hackaton.service;


import java.util.Base64;
import java.util.List;
import java.util.Random;
import javax.inject.Inject;
import javax.transaction.Transactional;
import com.stefanini.hackaton.dto.CorridaDto;
import com.stefanini.hackaton.dto.JogadorDto;
import com.stefanini.hackaton.dto.LogarDto;
import com.stefanini.hackaton.dto.PersonagemDto;
import com.stefanini.hackaton.dto.RegistroDto;
import com.stefanini.hackaton.entities.Jogador;
import com.stefanini.hackaton.parsers.JogadorParserDTO;
import com.stefanini.hackaton.parsers.PersonagemParserDTO;
import com.stefanini.hackaton.parsers.RegistroParserDTO;
import com.stefanini.hackaton.persistence.JogadorDAO;
import com.stefanini.hackaton.rest.exceptions.NegocioException;

@Transactional
public class JogadorService {

@Inject
JogadorParserDTO parser;

@Inject
PersonagemParserDTO personagemParser;

@Inject
RegistroParserDTO registroParser;

@Inject
JogadorDAO jogadorDao;

@Inject
PersonagemService personagem;

	public List<JogadorDto> listar() {
		return parser.toDTO(jogadorDao.list());
	}

	public JogadorDto obter(Integer id) {
		return parser.toDTO(jogadorDao.findById(id));
	}

	public RegistroDto inserir(RegistroDto dto) throws NegocioException {
		if (dto == null || dto.getSenha() == null || dto.getNickname() == null || dto.getPersonagem() == null) {
			throw new NegocioException("Por favor complete os dados.");
		}
		List<Jogador> listar = jogadorDao.list();
		for (Jogador jogador : listar) {
			if (jogador.getNickname().equalsIgnoreCase(dto.getNickname())) {
				throw new NegocioException("Usuario já existe.");
			}
		}
		if (tamanhoPassword(dto.getSenha())) {
			throw new NegocioException("Sua senha deve conter entre 6 e 8 caracteres.");
		}
		jogadorDao.insert(registroParser.toEntity(dto));
		return dto;
	}

	private Boolean tamanhoPassword(String senhaCript) {
		String criptografia = new String(Base64.getDecoder().decode(senhaCript));
		return criptografia.length() > 8 || criptografia.length() < 6;
	}

	public JogadorDto alterar(Integer id, JogadorDto dto) {
		Jogador jogador = jogadorDao.findById(id);
		jogador.setNickname(dto.getNickname());

		jogadorDao.update(jogador);
		return dto;
	}

	public void excluir(Integer id) {
		jogadorDao.removeById(id);
	}

	public JogadorDto realizarLogin(LogarDto logar) throws NegocioException {
		for (Jogador jogador : jogadorDao.list()) {
			if (jogador.getNickname().equalsIgnoreCase(logar.getNickname())) {
				if (jogador.getSenha().equals(logar.getSenha())) {
					return parser.toDTO(jogador);
				}
				throw new NegocioException("Sua senha está incorreta.");
			}
		}
		throw new NegocioException("Usuário não encontrado.");
	}

	public CorridaDto realizarCorrida() {
		CorridaDto correndo = new CorridaDto();

		PersonagemDto Mario = personagem.obter(1);
		PersonagemDto Luigi = personagem.obter(2);
		PersonagemDto PrincesaPeach = personagem.obter(3);
		PersonagemDto Yoshi = personagem.obter(4);
		PersonagemDto Toad = personagem.obter(5);
		PersonagemDto ReiBowser = personagem.obter(6);
		PersonagemDto DonkeyKong = personagem.obter(7);

		int inicio = 0;
		int fim = 2000;

		Integer mario = 0;
		Integer luigi = 0;
		Integer princesaPeach = 0;
		Integer yoshi = 0;
		Integer toad = 0;
		Integer reiBowser = 0;
		Integer donkeyKong = 0;

		while (inicio < fim) {
			Random gerador = new Random();

			mario = Mario.getVelocidade() + Mario.getAceleracao()
					- gerador.nextInt(Mario.getPeso() + gerador.nextInt(Mario.getTurbo()));
			luigi = Luigi.getVelocidade() + Luigi.getAceleracao()
					- gerador.nextInt(Luigi.getPeso() + gerador.nextInt(Luigi.getTurbo()));
			princesaPeach = PrincesaPeach.getVelocidade() + PrincesaPeach.getAceleracao()
					- gerador.nextInt(PrincesaPeach.getPeso() + gerador.nextInt(PrincesaPeach.getTurbo()));
			yoshi = Yoshi.getVelocidade() + Yoshi.getAceleracao()
					- gerador.nextInt(Yoshi.getPeso() + gerador.nextInt(Yoshi.getTurbo()));
			toad = Toad.getVelocidade() + Toad.getAceleracao()
					- gerador.nextInt(Toad.getPeso() + gerador.nextInt(Toad.getTurbo()));
			reiBowser = ReiBowser.getVelocidade() + ReiBowser.getAceleracao()
					- gerador.nextInt(ReiBowser.getPeso() + gerador.nextInt(ReiBowser.getTurbo()));
			donkeyKong = DonkeyKong.getVelocidade() + DonkeyKong.getAceleracao()
					- gerador.nextInt(DonkeyKong.getPeso() + gerador.nextInt(DonkeyKong.getTurbo()));

			inicio++;
		}

		if (mario > luigi && mario > princesaPeach && mario > yoshi && mario > toad && mario > reiBowser
				&& mario > donkeyKong) {
			correndo.setIdPersonagem(1);
			return correndo;
		} else if (luigi > princesaPeach && luigi > yoshi && luigi > toad && luigi > reiBowser && luigi > donkeyKong) {
			correndo.setIdPersonagem(2);
			return correndo;
		} else if (princesaPeach > yoshi && princesaPeach > toad && princesaPeach > reiBowser
				&& princesaPeach > donkeyKong) {
			correndo.setIdPersonagem(3);
			return correndo;
		} else if (yoshi > toad && yoshi > reiBowser && yoshi > donkeyKong) {
			correndo.setIdPersonagem(4);
			return correndo;
		} else if (toad > reiBowser && toad > donkeyKong) {
			correndo.setIdPersonagem(5);
			return correndo;
		} else if (toad > donkeyKong) {
			correndo.setIdPersonagem(6);
			return correndo;
		} else {
			correndo.setIdPersonagem(7);
			return correndo;
		}
	}
}
